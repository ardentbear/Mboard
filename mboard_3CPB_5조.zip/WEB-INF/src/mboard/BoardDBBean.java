package mboard;

import mboard.BoardDataBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDBBean {

    private static BoardDBBean instance = new BoardDBBean();

    //
    public static BoardDBBean getInstance() {
        return instance;
    }

    private BoardDBBean() {
    }

    //
    private Connection getConnection() throws Exception {
        Context initCtx = new InitialContext();
        Context envCtx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) envCtx.lookup("jdbc/MySQLDB2");
        return ds.getConnection();
    }

    public String registerCard(BoardDataBean card) throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;

        String sql = "";

        try {
            conn = getConnection();

            sql = "insert into card(card_company_name, card_employee, card_phone, card_email," +
                    "card_ip, card_memo, card_file_name, card_member_id) values(?,?,?,?,?,?,?,?)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, card.getCard_company_name());
            pstmt.setString(2, card.getCard_employee());
            pstmt.setString(3, card.getCard_phone());
            pstmt.setString(4, card.getCard_email());
            pstmt.setString(5, card.getCard_ip());
            pstmt.setString(6, card.getCard_memo());
            pstmt.setString(7, card.getCard_file_name());
            pstmt.setString(8, card.getCard_member_id());
            count = pstmt.executeUpdate();
            if (count == 1)
                return "success";
            else
                return "fail";

        } catch (Exception ex) {
            ex.printStackTrace();
            return "fail";

        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
    }

    public BoardDataBean getCardDetail(String num) {
        int cardNum = Integer.parseInt(num);
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BoardDataBean card;

        String sql = "";
        try {
            conn = getConnection();

            sql = "update card set card_view_count = card_view_count + 1 where card_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, cardNum);
            pstmt.executeUpdate();

            sql = "select * from card where card_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, cardNum);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                card = new BoardDataBean();
                card.setCard_member_id(rs.getString("card_member_id"));
                card.setCard_view_count(rs.getInt("card_view_count"));
                card.setCard_register_date(rs.getTimestamp("card_register_date"));
                card.setCard_company_name(rs.getString("card_company_name"));
                card.setCard_employee(rs.getString("card_employee"));
                card.setCard_phone(rs.getString("card_phone"));
                card.setCard_email(rs.getString("card_email"));
                card.setCard_memo(rs.getString("card_memo"));
                card.setCard_file_name(rs.getString("card_file_name"));
            } else
                card = null;

        } catch (Exception e) {
            e.printStackTrace();
            card = null;
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return card;
    }

    //
    public int getArticleCount()
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int x = 0;

        try {
            conn = getConnection();

            pstmt = conn.prepareStatement("select count(*) from card");
            rs = pstmt.executeQuery();

            if (rs.next()) {
                x = rs.getInt(1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }

    //
    public List<BoardDataBean> getArticles(int start, int end)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<BoardDataBean> articleList = null;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "select * from card order by card_id desc limit ?,? ");
            pstmt.setInt(1, start - 1);
            pstmt.setInt(2, end);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                articleList = new ArrayList<BoardDataBean>(end);
                do {
                    BoardDataBean article = new BoardDataBean();
                    article.setCard_id(rs.getInt("card_id"));
                    article.setCard_company_name(rs.getString("card_company_name"));
                    article.setCard_employee(rs.getString("card_employee"));
                    article.setCard_phone(rs.getString("card_phone"));
                    article.setCard_email(rs.getString("card_email"));
                    article.setCard_memo(rs.getString("card_memo"));
                    article.setCard_file_name(rs.getString("card_file_name"));
                    article.setCard_register_date(rs.getTimestamp("card_register_date"));
                    article.setCard_view_count(rs.getInt("card_view_count"));
                    article.setCard_ip(rs.getString("card_ip"));
                    article.setCard_member_id(rs.getString("card_member_id"));

                    articleList.add(article);
                } while (rs.next());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return articleList;
    }

    //
    public int getSearchArticleCount(String s, String scope)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "";
        int x = 0;

        try {
            conn = getConnection();
            if (scope.equals("all")) {
                sql = "select count(*) from card, member where member_id = card_member_id and (card_company_name like ? or card_employee like ? or card_memo like ? or member_name = ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
                pstmt.setString(2, "%" + s + "%");
                pstmt.setString(3, "%" + s + "%");
                pstmt.setString(4, s);
            } else if (scope.equals("company_name")) {
                sql = "select count(*) from card where card_company_name like ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
            } else if (scope.equals("member_id")) {
                sql = "select count(*) from card, member where member_id = card_member_id and member_name = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, s);
            } else if (scope.equals("memo")) {
                sql = "select count(*) from card where card_memo like ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
            }
            else if (scope.equals("employee")) {
                sql = "select count(*) from card where card_employee like ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
            }

            rs = pstmt.executeQuery();

            if (rs.next()) {
                x = rs.getInt(1);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }

    //
    public List<BoardDataBean> getArticles(int start, int end, String s, String scope)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<BoardDataBean> articleList = null;
        String sql = "";

        try {
            conn = getConnection();

            if (scope.equals("all")) {
                sql = "select * from card, member where member_id = card_member_id and (card_company_name like ? or card_employee like ? or card_memo like ? or member_name = ?) order by card_id desc limit ?, ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
                pstmt.setString(2, "%" + s + "%");
                pstmt.setString(3, "%" + s + "%");
                pstmt.setString(4, s);
                pstmt.setInt(5, start - 1);
                pstmt.setInt(6, end);
            } else if (scope.equals("company_name")) {
                sql = "select * from card where card_company_name like ? order by card_id desc limit ?,?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
                pstmt.setInt(2, start - 1);
                pstmt.setInt(3, end);
            } else if (scope.equals("member_id")) {
                sql = "select * from card, member where member_id = card_member_id and member_name = ? order by card_id desc limit ?,?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, s);
                pstmt.setInt(2, start - 1);
                pstmt.setInt(3, end);
            } else if (scope.equals("memo")) {
                sql = "select * from card where card_memo like ? order by card_id desc limit ?,?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
                pstmt.setInt(2, start - 1);
                pstmt.setInt(3, end);
            }
            else if (scope.equals("employee")) {
                sql = "select * from card where card_employee like ? order by card_id desc limit ?,?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, "%" + s + "%");
                pstmt.setInt(2, start - 1);
                pstmt.setInt(3, end);
            }
            rs = pstmt.executeQuery();

            if (rs.next()) {
                articleList = new ArrayList<BoardDataBean>(end);
                do {
                    BoardDataBean article = new BoardDataBean();
                    article.setCard_id(rs.getInt("card_id"));
                    article.setCard_company_name(rs.getString("card_company_name"));
                    article.setCard_employee(rs.getString("card_employee"));
                    article.setCard_phone(rs.getString("card_phone"));
                    article.setCard_email(rs.getString("card_email"));
                    article.setCard_memo(rs.getString("card_memo"));
                    article.setCard_file_name(rs.getString("card_file_name"));
                    article.setCard_register_date(rs.getTimestamp("card_register_date"));
                    article.setCard_view_count(rs.getInt("card_view_count"));
                    article.setCard_ip(rs.getString("card_ip"));
                    article.setCard_member_id(rs.getString("card_member_id"));

                    articleList.add(article);
                } while (rs.next());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return articleList;
    }

    //
    public BoardDataBean getArticle(int card_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BoardDataBean article = null;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "update card set card_view_count=card_view_count+1 where card_id = ?");
            pstmt.setInt(1, card_id);
            pstmt.executeUpdate();

            pstmt = conn.prepareStatement(
                    "select * from card where card_id = ?");
            pstmt.setInt(1, card_id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                article = new BoardDataBean();
                article.setCard_id(rs.getInt("card_id"));
                article.setCard_company_name(rs.getString("card_company_name"));
                article.setCard_employee(rs.getString("card_employee"));
                article.setCard_phone(rs.getString("card_phone"));
                article.setCard_email(rs.getString("card_email"));
                article.setCard_memo(rs.getString("card_memo"));
                article.setCard_file_name(rs.getString("card_file_name"));
                article.setCard_register_date(rs.getTimestamp("card_register_date"));
                article.setCard_view_count(rs.getInt("card_view_count"));
                article.setCard_ip(rs.getString("card_ip"));
                article.setCard_member_id(rs.getString("card_member_id"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return article;
    }

    //
    public BoardDataBean updateGetArticle(int card_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        BoardDataBean article = null;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement("select * from card where card_id = ?");
            pstmt.setInt(1, card_id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                article = new BoardDataBean();
                article.setCard_id(rs.getInt("card_id"));
                article.setCard_company_name(rs.getString("card_company_name"));
                article.setCard_employee(rs.getString("card_employee"));
                article.setCard_phone(rs.getString("card_phone"));
                article.setCard_email(rs.getString("card_email"));
                article.setCard_memo(rs.getString("card_memo"));
                article.setCard_file_name(rs.getString("card_file_name"));
                article.setCard_register_date(rs.getTimestamp("card_register_date"));
                article.setCard_view_count(rs.getInt("card_view_count"));
                article.setCard_ip(rs.getString("card_ip"));
                article.setCard_member_id(rs.getString("card_member_id"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return article;
    }

    //
    public String getMember_name(String member_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String member_name = "";
        String sql = "";

        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "select member_name from member where member_id = ?");
            pstmt.setString(1, member_id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                member_name = rs.getString("member_name");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return member_name;
    }

    //
    public int updateArticle(BoardDataBean article)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String sql = "";
        int x = -1;
        try {
            conn = getConnection();

            sql = "update card set card_company_name=?,card_employee=?,card_phone=?,card_email=?";
            sql += ",card_memo=? where card_id=?";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, article.getCard_company_name());
            pstmt.setString(2, article.getCard_employee());
            pstmt.setString(3, article.getCard_phone());
            pstmt.setString(4, article.getCard_email());
            pstmt.setString(5, article.getCard_memo());
            pstmt.setInt(6, article.getCard_id());
            pstmt.executeUpdate();
            x = 1;

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }

    //
    public boolean isWriter(int card_id, String host_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String writer_id = "";
        boolean x = false;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "select card_member_id from card where card_id = ?");
            pstmt.setInt(1, card_id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                writer_id = rs.getString("card_member_id");
                if (writer_id.equals(host_id)) {
                    x = true; //
                } else
                    x = false; //
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }

    public int deleteArticle(int card_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int x = -1;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "delete from card where card_id=?");
            pstmt.setInt(1, card_id);
            pstmt.executeUpdate();
            x = 1; //

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }

    public int deleteMemberArticle(String member_id)
            throws Exception {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int x = -1;
        try {
            conn = getConnection();

            pstmt = conn.prepareStatement(
                    "delete from card where card_member_id=?");
            pstmt.setString(1, member_id);
            if (pstmt.executeUpdate() > 0)
                x = 1;
            else
                x = 0;

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null)
                try {
                    rs.close();
                } catch (SQLException ex) {
                }
            if (pstmt != null)
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                }
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException ex) {
                }
        }
        return x;
    }
}