package mboard;

import java.sql.Timestamp;

public class BoardDataBean {
	private int card_id; //id
    private String card_company_name; //com name
    private String card_employee; //emp
    private String card_phone; //phone
    private String card_email; //email
    private String card_memo; //memo
    private String card_file_name; //file name
    private Timestamp card_register_date; //register_date
    private int card_view_count; //view count
    private String card_ip; //ip
    private String card_member_id;	//member id
 
    
	public int getCard_id() {
		return card_id;
	}
	public void setCard_id(int card_id) {
		this.card_id = card_id;
	}
	
	public String getCard_company_name() {
		return card_company_name;
	}
	public void setCard_company_name(String card_company_name) {
		this.card_company_name = card_company_name;
	}
	
	public String getCard_employee() {
		return card_employee;
	}
	public void setCard_employee(String card_employee) {
		this.card_employee = card_employee;
	}
	
	public String getCard_phone() {
		return card_phone;
	}
	public void setCard_phone(String card_phone) {
		this.card_phone = card_phone;
	}
	
	public String getCard_email() {
		return card_email;
	}
	public void setCard_email(String card_email) {
		this.card_email = card_email;
	}
	
	public String getCard_memo() {
		return card_memo;
	}
	public void setCard_memo(String card_memo) {
		this.card_memo = card_memo;
	}
	
	public String getCard_file_name() {
		return card_file_name;
	}
	public void setCard_file_name(String card_file_name) {
		this.card_file_name = card_file_name;
	}
	
	public Timestamp getCard_register_date() {
		return card_register_date;
	}
	public void setCard_register_date(Timestamp card_register_date) {
		this.card_register_date = card_register_date;
	}
	
	public int getCard_view_count() {
		return card_view_count;
	}
	public void setCard_view_count(int card_view_count) {
		this.card_view_count = card_view_count;
	}
	
	public String getCard_ip() {
		return card_ip;
	}
	public void setCard_ip(String card_ip) {
		this.card_ip = card_ip;
	}
	
	public String getCard_member_id() {
		return card_member_id;
	}
	public void setCard_member_id(String card_member_id) {
		this.card_member_id = card_member_id;
	}
}