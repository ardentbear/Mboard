package mboard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import mboard.UserDataBean;

public class UserDBBean {

   private static UserDBBean instance = new UserDBBean();

   //
   public static UserDBBean getInstance() {
      return instance;
   }

   private UserDBBean() {
   }

   //
   private Connection getConnection() throws Exception {
      Context initCtx = new InitialContext();
      Context envCtx = (Context) initCtx.lookup("java:comp/env");
      DataSource ds = (DataSource) envCtx.lookup("jdbc/MySQLDB2");
      return ds.getConnection();
   }

   

   public int deleteMember(String id, String pass) throws Exception {
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;

         String passwd = "";
         int x = -1;
         try {
            conn = getConnection();

            pstmt = conn.prepareStatement("delete from member where member_id=?");
            pstmt.setString(1, id);
            if(pstmt.executeUpdate()>0)
				x=1;

         } catch (Exception ex) {
            ex.printStackTrace();
         } finally {
            if (rs != null)
               try {
                  rs.close();
               } catch (SQLException ex) {
               }
            if (pstmt != null)
               try {
                  pstmt.close();
               } catch (SQLException ex) {
               }
            if (conn != null)
               try {
                  conn.close();
               } catch (SQLException ex) {
               }
         }
         return x;
      }
   
   public UserDataBean getArticles(String id)
            throws Exception {
       Connection conn = null;
       PreparedStatement pstmt = null;
       ResultSet rs = null;
       UserDataBean articleList=null;
       try {
           conn = getConnection();
           
           pstmt = conn.prepareStatement(
              "select * from member where member_id = ?");
           pstmt.setString(1, id);
           rs = pstmt.executeQuery();

           if (rs.next()) {
               articleList = new UserDataBean();
               articleList.setId(rs.getString(1));
               articleList.setPass(rs.getString(2));
               articleList.setName(rs.getString(3));
           }
         
       } catch(Exception ex) {
           ex.printStackTrace();
       } finally {
           if (rs != null) try { rs.close(); } catch(SQLException ex) {}
           if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
           if (conn != null) try { conn.close(); } catch(SQLException ex) {}
       }
      return articleList;
   }
   
   public int loginCheck(String id, String pw) 
   {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;

      String dbPW = ""; 
      int x = -1;

      try {
         
         
         conn = getConnection();
         pstmt = conn.prepareStatement("SELECT member_password FROM member WHERE member_id=?");
         pstmt.setString(1, id);
         rs = pstmt.executeQuery();

         if (rs.next()) 
         {
            dbPW = rs.getString("password"); 

            if (dbPW.equals(pw)) 
               x = 1; 
            else              
               x = 0; 
            
         } else {
            x = -1; 
         }

         return x;

      } catch (Exception sqle) {
         throw new RuntimeException(sqle.getMessage());
      } finally {
         try{
            if ( pstmt != null ){ pstmt.close(); pstmt=null; }
            if ( conn != null ){ conn.close(); conn=null;   }
         }catch(Exception e){
            throw new RuntimeException(e.getMessage());
         }
      }
   }    
   

}